package com.example.leta_sasa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
